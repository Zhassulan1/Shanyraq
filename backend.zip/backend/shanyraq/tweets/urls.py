from django.urls import path
from .views import ListingList, ListingDetail

urlpatterns = [
    path("listing/", ListingList.as_view()),
    path("listing/<int:id>", ListingDetail.as_view()),
]
